from django.db import models

# Create your models here.
class Book(models.Model):
    title=models.CharField(max_length=100)
    author=models.CharField(max_length=100)
    pdf=models.FieldField(upload_to='book/pdf')
    cover=models.ImageField(upload_to='book/cover',null=True,blank=True)
